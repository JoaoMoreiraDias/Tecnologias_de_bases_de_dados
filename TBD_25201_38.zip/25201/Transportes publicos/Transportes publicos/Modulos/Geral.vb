﻿Module Geral
    Public dbCNNstr As String = "Data Source=(local);Initial Catalog=""Transportes Publicos"";Integrated Security=True"
End Module
