﻿Module Geral
    'Declarar a database connection string a base de dados
    Public dbCNNstr As String = "Data Source=(local);Initial Catalog=Trabalho Prático 2 - Investigação Criminal;Integrated Security=True"
End Module
